// $(function () {
//   $(".owl-carousel").owlCarousel({
//     loop: true,
//     // stagePadding: 100,
//     margin: 10,
//     center: true,
//     items: 2,
//     autoplay: true,
//     autoplayTimeout: 3000,
//     lazyLoad: true,
//     // responsive: {
//     //   0: {
//     //     items: 2,
//     //   },
//     //   485: {
//     //     items: 3,
//     //   },
//     //   728: {
//     //     items: 4,
//     //   },
//     //   960: {
//     //     items: 4,
//     //   },
//     //   1200: {
//     //     items: 4,
//     //   },
//     // },
//   });
// });
